import Wigner as wig
import QPR as qr
import numpy as np

#Negativity of state
def negs(QPRs):

    summ = 0
    for entry in QPRs:
        summ +=abs(entry)
    return summ

#Negativity of unitary
def negu(QPRu):

    summs = []
    for row in QPRu:
        summ = 0
        for entry in row:
            summ += abs(entry)
        summs.append(summ)
    negu = max(summs)
    return(negu)

#Negativity of measure
def negm(QPRm):

    summ = 0
    for entry in QPRm:
        summ += abs(entry)
    return summ

#Testing example
FG = wig.DW(2)
frame = FG[:4]
test = qr.QPRs(np.array([[1,0],[0,0]]), frame)

