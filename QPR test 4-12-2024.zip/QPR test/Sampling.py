import Wigner as wig
import QPR as qr
import Negativity as ne
import numpy as np
import random
import math

#sign function
def sign(num):

    if num < 0:
        return -1
    else:
        return 1

#estimator p, QPRu_list is set of QPRu for the circuit
def p(QPRu_list, QPRs, QPRm):

    index0 = random.choice(range(len(QPRs)))     #Choosing which entry of QPR of state (d**2 entries)
    lambda0 = QPRs[index0]                       #Value of choosen entry
    p_traj = ne.negs(QPRs) * sign(lambda0)
    neglist = []

    for u in QPRu_list:
        indexi = random.choice(range(len(u[0]))) #Choose S_ij entry (index0 determines row)
        lambdai = u[index0][indexi]
        temp2 = ne.negu(u) * sign(lambdai)
        neglist.append(temp2)

    for entry in neglist:
        p_traj *= entry
    final = p_traj * QPRm[index0]
    return final

#calculates average of estimator p
def sampling(QPRu_list, QPRs, QPRm):
  
    #calculates total forward negativity
    negtot = ne.negs(QPRs)         
    for QPRu in QPRu_list:      #multiples by negativity of each s
        negtot *= ne.negu(QPRu)
    absm = []
    for entry in QPRm:          #list of absolute values of m
        absm.append(abs(entry))
    negtot *= max(absm)

    #samples needed, precision 0.01, confidence 95%
    samples_needed = math.ceil(2 * (0.01**-2) * (negtot**2) * np.log(2/0.05))
    print(samples_needed)
    
    samples = 0
    ptotal = 0
    while samples < samples_needed:
        ptotal += p(QPRu_list, QPRs, QPRm)
        samples += 1
    return ptotal/samples

#Testing
FG = wig.DW(2)
frame = FG[:4]
dual = FG[4:]
Hadamard = (1/np.sqrt(2)) * np.array([[1,1], [1,-1]])
h = [qr.QPRu(Hadamard, frame, dual)]
s = qr.QPRs(np.array([[1,0],[0,0]]), frame)
m = qr.QPRm(np.array([[1,0],[0,0]]), dual)
test = sampling(h, s, m)
