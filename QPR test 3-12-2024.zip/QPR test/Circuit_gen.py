import Wigner as wig
import QPR as qr
import numpy as np
import random

#depth = number of steps/gates, total = number of qudits

#Generates random circuit
def circuit_gen(depth, total):

    step = 0
    order = []
    while step < depth:
        gate = random.choice(range(3)) # 0 = Hadamard, 1 = Phase, 2 = CNOT
        if gate != 2:
            order.append((gate, random.choice(range(total))))      #(Hadamard/Phase, target) 
        else:
            order.append((gate, random.sample(range(total), k=2))) #(CNOT, (control, target))
        step += 1
    return order    #e.g. (1,0) - Phase on qudit 0, (2, (2,3)) - CNOT, qudit 2 is control qudit 3 is target

#Calculates the unitaries at each step of circuit
def circuit_run(order):
    '''
    #Qutrit case
    omega = np.exp(complex(0, 2*np.pi/3))
    Hadamard = complex(0, -1/np.sqrt(3)) * np.array([[1,1,1],
                                                     [1, omega, omega**2],
                                                     [1, omega**2, omega]])
    Phase = (omega**24) * np.diag([1,1,omega])
    CNOT = wig.X(3)
    '''

    #Qubit case
    Hadamard = (1/np.sqrt(2)) * np.array([[1, 1],
                                          [1, -1]])
    Phase = np.array([[1, 0],
                      [0, complex(0, 1)]])
    CNOT = wig.X(2)
    gates = [Hadamard, Phase, CNOT]

    ulist = []
    for entry in order:
        #Hadamard/Phase
        if entry[0] != 2:
            target = entry[1]

            #step 0
            if target == 0:
                unitary = [gates[entry[0]]]
            else:    
                unitary = [np.eye(2)]
                
            step = 1

            #tensor product identity until target is reached
            while step < target:
                temp = unitary[step - 1]
                temp2 = np.kron(temp, np.eye(2))
                unitary.append(temp2)
                step += 1

            #places Hadamard/Phase gate at target (if not already at step 0)
            if step == target:
                temp = unitary[step - 1]
                temp2 = np.kron(temp, gates[entry[0]])
                unitary.append(temp2)
                step += 1

            #tensor product the remaining identities
            while step < total:
                temp = unitary[step - 1]
                temp2 = np.kron(temp, np.eye(2))
                unitary.append(temp2)
                step += 1
            ulist.append(unitary[step - 1])
            
        #CNOT
        else:
            target = entry[1][1]

            #step 0
            if target == 0:
                unitary = [gates[2]]
            else:
                unitary = [np.eye(2)]
                
            step = 1

            #tensor product identity unitl target is reached (control qudit is left alone)
            while step < target:
                temp = unitary[step - 1]
                temp2 = np.kron(temp, np.eye(2))
                unitary.append(temp2)
                step += 1

            #performs operation at target qudit (if not already at step 0)
            temp = unitary[step - 1]
            temp2 = np.kron(temp, gates[2])
            unitary.append(temp2)
            step += 1

            #fill the rest of the diagonal
            while step < total:
                temp = unitary[step - 1]
                temp2 = np.kron(temp, np.eye(2))
                unitary.append(temp2)
                step += 1
            ulist.append(unitary[step - 1])
    return ulist
'''
#Qutrit
FG = wig.DW(8)
frame = FG[:8**2]
dual = FG[8**2:]
'''
#Qubit
FG = wig.DW(8)
frame = FG[:8**2]
dual = FG[8**2:]
total = 3
order = circuit_gen(5,3)
eg = [(2, [1, 0]),
      (1, 2),
      (2, [2, 1]),
      (2, [2, 0]),
      (1, 2)]
ulist = circuit_run(eg)
u = []
for entry in ulist:
    u.append(qr.QPRu(entry, frame, dual))
print(u[0])
print()
print(frame[63])
print()
print(dual[63])
