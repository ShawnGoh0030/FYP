import Wigner as wig
import QPR as qr
import Negativity as ne
import numpy as np
import random

#sign function
def sign(num):

    if num < 0:
        return -1
    else:
        return 1

#estimator p, QPRu_list is set of QPRu for the circuit
def p(QPRu_list, QPRs, QPRm):

    index0 = random.choice(range(len(QPRs)))   #Choosing which entry of QPR of state (d**2 entries)
    lambda0 = qr.QPRs[index0]                  #Value of choosen entry
    p_traj = negs(QPRs) * sign(lambda0)
    neglist = []

    for u in QPRu_list:
        indexi = random.choice(range(len(s[0]))) #Choose S_ij entry (index0 determines row)
        lambdai = s[index0][indexi]
        temp2 = ne.negu(s) * sign(lambdai)
        neglist.append(temp2)

    for entry in neglist:
        p_traj *= entry
    final = p_traj * qr.QPRm[index0]
    return final

#calculates average of estimator p
def sampling(ulist, QPRs, QPRm):

    #calculates QPR representation of each unitary
    total_dim = len(QPRs)**2 #total dimensionality of n qudits
    FG = wig.DW(total_dim)
    Frame = FG[:total_dim**2]
    Dual = FG[total_dim**2:]
    QPRu_list = []
    for unitary in ulist:
        temp = qr.QPRu(unitary, Frame, Dual)
        s_list.append(temp)

    #calculates total forward negativity
    negtot = ne.negs(QPRs)         
    for QPRu in QPRu_list:      #multiples by negativity of each s
        negtot *= ne.negu(s)
    absm = []
    for entry in QPRm:          #list of absolute values of m
        absm.append(abs(entry))
    negtot *= max(absm)

    #samples needed, precision 0.01, confidence 95%
    samples_needed = math.ceil(2 * (0.01**-2) * (negtot**2) * syp.log(2/0.95))
    print(samples_need)
    
    samples = 0
    ptotal = 0
    while samples < samples_needed:
        ptotal += p(QPRu_list, QPRs, QPRm)
        samples += 1
    return ptotal/samples
